// // // Insertion Sort
// // // Idea: Take an element from the unsorted array, place it in its corresponding position in the sorted part, and shift the elements accordingly.
// // // Time Complexity: O(N2) 

// // // Code
// package DSA.Sortings;

// class InsertionSort {
//     public static void printArray(int arr[]) {
//         for(int i=0; i<arr.length; i++) {
//             System.out.print(arr[i]+" ");
//         }
//         System.out.println();
//     }
//     public static void main(String args[]) {
//         int arr[] = {8, 7, 1, 3, 2};
//         //insertion sort
//         for(int i=1; i<arr.length; i++) {
//             int current = arr[i];//next element
//             // current = 7
//             int j = i - 1; // j = 1-1
//             // j = 8(previous element)
//             // 8 >= 0 && 8 > 7
//                 while(j >= 0 && arr[j] > current) {
//                    //Keep swapping
//                 //   next index = previous index.
//                     arr[j + 1] = arr[j];
//                     j--;
//                 }
//                 // 8 = current
//                 // 8 =  i(1 index)
//                 // 8 = 8
//             arr[j + 1] =  current;
//         }
//         printArray(arr);
//     }
// }
