// Selection Sort
// Idea: The inner loop selects the minimum element in the unsorted array and places the elements in increasing order. 
// Time complexity: O(N2) 

// Code
import java.util.*;

class SelectionSorting {
   public static void printArray(int arr[]) {
       for(int i=0; i<arr.length; i++) {
           System.out.print(arr[i]+" ");
       }
       System.out.println();
   }
   public static void main(String args[]) {
       int arr[] = {7, 8, 1, 3, 2};
       //selection sort 
    // here compiler traverce(checking) the array.
       for(int i=0; i<arr.length-1; i++) {
           int smallest = i;
        //    here we have to take a next number j(i + 1) greater than i.
           for(int j=i+1; j<arr.length; j++) {
            // if next number < previous number.
            // 1 < 7
               if(arr[j] < arr[smallest]) {
                   smallest = j;
               }
           }
           //swap
        //    temp = 1;
        // Here in this three lines we are replacing value j(1) with i(7)
           int temp = arr[smallest];
           // arr[smallest] = 7;
           arr[smallest] = arr[i];
        //   7 = temp;
           arr[i] = temp;
       }
       printArray(arr);
   }}