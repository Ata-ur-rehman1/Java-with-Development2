// Q1. Print numbers from 5 to 1?
// import java.util.*;

// import java.util.*;
// public class Recursion1{
// public static void printNum(int n){
//     if(n == 0){
//         return ;
//     }
//     System.out.println(n);
//     printNum(n - 1);
// }
//     public static void main(String args[]){
//         int n = 6;
//         printNum(n);
        
//     }
// }
// Q2. Print numbers from 6 to 1?

// public class Recursion1{
//     public static void printNumber(int n){
//         if(n == 0){
//             return;
//         }
//         System.out.println(n);
//        printNumber(n - 1);
//     }
//     public static void main(String args[]){
//         int n = 5;
//         printNumber(n);
//     }
// }

// Q3. Print numbers from 1 to 6?

// import java.util.*;

// public class Recursion1{
//     public static void printNumber(int n){
//         if(n == 6){
//             return;
//         }
//         System.out.println(n);
//        printNumber(n + 1);
//     }
//     public static void main(String args[]){
//         int n = 1;
//         printNumber(n);
//     }
// }

// Q4. Print sum of first n natural numbers.
// import java.util.*;
// public class Recursion1{
//     public static void printNumber(int i, int n, int sum){
//         if(i == n){
//             sum += i;
//         System.out.println(sum);
//             return;
//         }
//         sum += i;
//        printNumber(i + 1, n, sum);
//        System.out.println(i);
//     }
//     public static void main(String args[]){
//         printNumber(1, 5 , 0);
//     }
// }

// Q5. Print Factorial of a number n.
// import java.util.*;
// public class Recursion1 {
// public static int printFactorial(int n){
//     if(n == 0 || n == 1){
//     return 1;
//     }else if(n < 0){
//         System.out.println( n + " " + "is invalid number");
//         return n;
//     }
//     int num_fac1 = printFactorial(n - 1);
//     int num_fac = n*num_fac1;
//     return num_fac;
// }
//     public static void main(String args[]){
//         Scanner sc = new Scanner(System.in);
//         int n = sc.nextInt();
//         int ans = printFactorial(n);
//     System.out.println(ans);
// }
// }
// Q6. Fabonacci Sequence:

// import java.util.*;
// public class RecursionClass2{
//     public static void printFabonacci(int a, int b, int n){
//         if(n == 0){
//             return;
//         }
//         int c = a + b;
//         System.out.println(c);
//         // c = a + b and b because here we use b for next coming term.
//         printFabonacci(b, c, n-1);
//     }
//         public static void main(String args[]){
//             // 0,1,1,2,3,5,8
//             // 0+1=> 1+1=> 1+2=> 2+3=> 3+5=> 8
//             int a = 0, b = 1;
//             System.out.println(a);
//             System.out.println(b);
//             int n = 7;
//             printFabonacci(a, b, n - 2);
//         }
//     }

