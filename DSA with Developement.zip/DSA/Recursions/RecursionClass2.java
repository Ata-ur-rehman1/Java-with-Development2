// Tower of hanoi:
// Rules:
// Only one disk transfer in one step.
// 2. Smaller disks are always on the top of ghe larger disks.

// We have three towers fixed in the a way. Their name are A, B, C for simple concept. A is source, Bis helper and C is destination. 
// In the first, we have lot of disks in the form stacks to n time.
// For n = 1 (means we have one disk).
// If we have a disk in source so we have also helper and destination. So then, we will directly transfer disk from source to 
// destination without help of helper.
// For n = 2 (means we have two disks).
// If we have two disk in source so we have also helper and destination. So then, we will not directly transfer these disks from 
// source to destination. Here, we will get help from helper. Initially, the first small disk will transfer to helper then last disk 
// will directly transfer from source to destination then the first small disk will transfer from helper to destination.

// For n = 3 (means we have three disks).
// If we have three disk in source so we have also helper and destination. So then, we will not directly transfer disk from source to
// destination. Here, we will get help from helper. Initially, the first two small disk will transfer to helper then, last disk
// will directly transfer from source to destination then the last disk first two small disks will transfer from helper to 
// destination.
// 1. Here we have three steps for transfering first two disks from source to helper considering that we use destination as a helper.
// and helper as a destination and destination will consider itself as a destination.
// 2. Then we have one step for transfering last disk source to destination.
// 3. Then we have more three for transfering from helper to destination by thinking n = 2 and considering that we use source as a helper
// and helper as a source.
// Logic:
// 1. Transfering disk n-1 from source to helper, to assuming  helper as a destination.

// 2. Transfering last disk from source to destination, to assuming destination will consider itself as a destination.

// 3. Transfering disk n-1 from helper to destination, to assuming  source as a helper.
// public class RecursionClass2 {
// public static void towerOfHanoi(int n, String src, String helper, String dest) {
// if(n == 1) {
// System.out.println("transfer disk " + n + " from " + src + " to " + dest);
// return;
// }
// //transfer top n-1 from src to helper using dest as 'helper'
// towerOfHanoi(n-1, src, dest, helper);
// //transfer nth from src to dest
// System.out.println("transfer disk " + n + " from " + src + " to " + des);
// //transfer n-1 from helper to dest using src as 'helper'
// towerOfHanoi(n-1, helper, src, dest);
// }
// public static void main(String args[]) {
// int n = 3;
// towerOfHanoi(n, "A", "B", "C");
// }
// }

// It's time complexity is O((2^n )- 1) = O(2^n).

// Space & Time Complexity:
// 1. Space complexity:
// Initially, on index 3 there will d print there we will pass "abcd";
// Then, on index 2 there will c print there again we will pass "abcd";
// Then, on index 1 there will b print there again we will pass "abcd";
// Then, on index 0 there will a print there again we will pass "abcd";
// As we will perform action, then we will return values (d, c, b, a) from index 3 to index 0 the data in the form of stacks will 
// delete.

// 2. Time complexity: 
// The String has traversed from index 3 to 0 so the time complexity is equal to length of string. 
// Time complexity = O(n). n is a number of terms(length of strings)
// public class index{
//     public static void reverseChar(String str, int idx) {
//         // index is variable key can used for recursion.
//         if(idx == 0) {
//             System.out.print(str.charAt(idx));
//             return;
//         }
//         // Here we are shifting the fast indexs (chars) at first begining.
//         System.out.print(str.charAt(idx));
//         // Here we decide which index(char) we want take.
//         reverseChar(str, idx - 1);
//     }
//         public static void main(String args[]) {
//             // We have four indexs (a, b, c, d)
//         String str = "abcd";
//         reverseChar(str, str.length() -1);
// }
// }

// Q3. Find the occurrence of the first and last occurrence of an element using recursion?

// Space & Time Complexity:
// The length of string is equal to O(n).

// public class RecursionClass2{
//     public static int first = -1;
//     public static int last = -1;
//     public static void findOccuranceOFIndex(String str, int idx, char el){
//         if(str.length() == idx){
//         return;
//         }
//         if(str.charAt(idx) == el){
//             if(first == -1){
//                 first = idx;
//             }else if(last == -1){
//                 last = idx;
//             }
//         }
//         findOccuranceOFIndex(str, idx + 1, el);
//     }
//     public static void main(String args[]){
//     String str = "taihuhiuhiauak";
//     char el = 'a';
//     findOccuranceOFIndex(str, 0, el);
//     System.out.println("First Occurance: " + first);
//     System.out.println("First Occurance: " + last);
//     }
// }

// Q4. Check if an array is sorted (strictly increasing).
// Space & Time Complexity:
// Number of n terms (Length of Array) is equal to O(n).

    public class RecursionClass2{
    public static boolean isSorted(int arr[], int idx){
        if(idx == arr.length - 1){
        return true;
        }else {
        return (arr[idx] < arr[idx + 1] ? isSorted(arr, idx + 1) : false);
        }
        }
        public static void main(String args[]){
        int arr[] = {1, 2, 3, 4, 5};
        System.out.println(isSorted(arr, 0));
    }
    }