const BecomeASeller = () => {
  return (
    <>
      <h1>BecomeASeller</h1>
    </>
  );
};
export default BecomeASeller;
