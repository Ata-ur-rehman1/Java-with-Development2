import { Link } from "react-router-dom";

const Footer = () => {
  return (
    <>
      <Link>
        <>Privacy Policy</>
      </Link>
    </>
  );
};

export default Footer;
