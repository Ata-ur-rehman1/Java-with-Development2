import React, { useState } from "react";
import {
  AiOutlineHome,
  AiOutlineShopping,
  AiOutlineLogin,
  AiOutlineUserAdd,
  AiOutlineShoppingCart,
} from "react-icons/ai";
import { FaHeart } from "react-icons/fa";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import "./Navigation.css";
import { useSelector, useDispatch } from "react-redux";
import { useLogoutMutation } from "../../redux/api/usersApiSlice";
import { logout } from "../../redux/features/auth/authSlice";
import FavoritesCount from "../Products/FavoritesCount";

const Navigation = () => {
  const { userInfo } = useSelector((state) => state.auth);
  const { cartItems } = useSelector((state) => state.cart);

  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [showSidebar, setShowSidebar] = useState(false);

  const toggleDropdown = () => {
    setDropdownOpen(!dropdownOpen);
  };

  const dispatch = useDispatch();
  const navigate = useNavigate();

  const [logoutApiCall] = useLogoutMutation();

  const logoutHandler = async () => {
    try {
      await logoutApiCall().unwrap();
      dispatch(logout());
      navigate("/login");
    } catch (error) {
      console.error(error);
    }
  };

  // const handleSearchChange = (e) => {
  //   dispatch(setProductFilter({ searchTerm: e.target.value }));

  //   const filteredProducts = data.filter((product) =>
  //     movie.name.toLowerCase().includes(e.target.value.toLowerCase())
  //   );

  //   dispatch(setFilteredProducts(filteredProducts));
  // };

  return (
    <>
      <div
        id="navigation-container"
        style={{
          height: "120px",
          width: "1358px",
          display: "flex",
          backgroundColor: "chocolate",
        }}
      >
        <div
          // className="flex flex-col justify-center space-y-4"
          style={{
            zIndex: 9999,
            display: "flex",
          }}
        >
          <div
            className="absolute"
            style={{
              marginLeft: "1220px",
              display: "flex",
              marginRight: "0px",
              marginTop: "60px",
            }}
          >
            <button
              onClick={toggleDropdown}
              className="flex items-center text-pink-800 focus:outline-none"
            >
              {userInfo ? (
                <span className="text-white">{userInfo.username}</span>
              ) : (
                <></>
              )}
              {userInfo && (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className={`h-4 w-4 ml-1 ${
                    dropdownOpen ? "transform rotate-180" : ""
                  }`}
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="white"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d={dropdownOpen ? "M5 15l7-7 7 7" : "M19 9l-7 7-7-7"}
                  />
                </svg>
              )}
            </button>

            {dropdownOpen && userInfo && (
              <ul
                className={`absolute right-0 mt-2 mr-14 space-y-2 bg-white text-gray-600 ${
                  !userInfo.isAdmin ? "-bottom-20" : "-bottom-80"
                } `}
              >
                {userInfo.isAdmin && (
                  <>
                    <li>
                      <Link
                        to="/admin/dashboard"
                        className="block px-4 py-2 hover:bg-gray-100"
                      >
                        Dashboard
                      </Link>
                    </li>
                    <li>
                      <Link
                        to="/admin/productlist"
                        className="block px-4 py-2 hover:bg-gray-100"
                      >
                        Products
                      </Link>
                    </li>
                    <li>
                      <Link
                        to="/admin/categorylist"
                        className="block px-4 py-2 hover:bg-gray-100"
                      >
                        Category
                      </Link>
                    </li>
                    <li>
                      <Link
                        to="/admin/orderlist"
                        className="block px-4 py-2 hover:bg-gray-100"
                      >
                        Orders
                      </Link>
                    </li>
                    <li>
                      <Link
                        to="/admin/userlist"
                        className="block px-4 py-2 hover:bg-gray-100"
                      >
                        Users
                      </Link>
                    </li>
                  </>
                )}
                <li>
                  <Link
                    to="/profile"
                    className="block px-4 py-2 hover:bg-gray-100"
                  >
                    Profile
                  </Link>
                </li>
                <li>
                  <button
                    onClick={logoutHandler}
                    className="block w-full px-4 py-2 text-left hover:bg-gray-100"
                  >
                    Logout
                  </button>
                </li>
              </ul>
            )}
          </div>
          <div className="flex">
            <Link
              to="/"
              style={{ fontSize: "50px", marginLeft: "50px" }}
              className="flex w-[3px] items-center transition-transform transform mr-2 mt-[1.5rem]"
            >
              <span className="">.NK</span>
            </Link>
          </div>
          <div className="">
            <Link
              to="/shop"
              style={{
                marginLeft: "150px",
              }}
              className="flex items-center transition-transform transform mr-2 pr-2 mt-[3rem]"
            >
              <AiOutlineShopping
                className="hover2"
                style={{ height: "40px", width: "30px" }}
              />
              <div className="pt-2" style={{ fontSize: "24px" }}>
                Shop
              </div>
            </Link>
          </div>
          <div className="input-container flex">
            <input
              style={{
                borderTopLeftRadius: "20px",
                borderBottomLeftRadius: "20px",
              }}
              className="input-container ml-[40px] h-[2.4rem] w-[29rem] mt-[50px]"
              placeholder="Type to Search Products"
              // value={moviesProduct.searchTerm}
              // onChange={handleSearchChange}
            />
            <button
              style={{
                borderTopRightRadius: "20px",
                borderBottomRightRadius: "20px",
                backgroundColor: "chartreuse",
                borderStyle: "none",
              }}
              className="h-[2.4rem] w-[60px] mt-[50px]"
            >
              Search
            </button>
          </div>
          <div
            className=""
            style={{
              display: "flex",
              marginTop: "90px",
            }}
          ></div>
          <Link to="/cart" className="flex" style={{ marginLeft: "70px" }}>
            <div className="hover2 flex items-center transition-transform transform mt-[1.5rem]">
              <AiOutlineShoppingCart
                style={{
                  height: "2rem",
                  display: "flex",
                  width: "2rem",
                }}
              />
              <div className="" style={{ fontSize: "20px" }}>
                Cart
              </div>
            </div>

            <div className="absolute top-9">
              {cartItems.length > 0 && (
                <span>
                  <span className="px-1 py-0 text-sm text-white bg-pink-500 rounded-full">
                    {cartItems.reduce((a, c) => a + c.qty, 0)}
                  </span>
                </span>
              )}
            </div>
          </Link>
          <Link
            to="/favorite"
            className="flex relative"
            style={{ marginLeft: "40px" }}
          >
            <div className="flex justify-center items-center transition-transform transform mr-2  mt-[1.5rem]">
              <FaHeart style={{ height: "30px", width: "30px" }} />
              <div className="" style={{ fontSize: "20px" }}>
                Favorites
              </div>{" "}
              <FavoritesCount />
            </div>
          </Link>
        </div>
        {!userInfo && (
          <>
            <div className="flex">
              <ul className="flex items-center">
                <li>
                  <Link to="/login" className="flex items-center">
                    {/* <AiOutlineLogin className="mr-1 mt-[4px]" size={26} /> */}
                    <span className="pt-5 pl-5 login">Login</span>
                  </Link>
                </li>
                <li>
                  <Link to="/register" className="flex ml-8">
                    {/* <AiOutlineUserAdd className="pr-1 mt-[4px]" size={26} /> */}
                    <span className="pt-5 login">Signup</span>
                  </Link>
                </li>
              </ul>
            </div>
          </>
        )}
      </div>
      <div className="nav1"></div>
      <nav className="nav w-[179px] h-[70px] bg-chocolate">
        <div className="flex mr-2 pt-[4px] pl-2 w-[140px] h-[40px] nav3 absolute ml-8 mt-[1.5rem]">
          <Link to="/specialProducts">Special Products</Link>
        </div>
        <div className="ml-[160px]">
          <div className="flex mr-2 pt-[4px] pl-2 w-[200px] h-[40px] nav3 absolute ml-8 mt-[1.5rem]">
            <Link to="/ai">Get Help From AI Chatbot</Link>
          </div>
        </div>
        <div className="ml-[400px]">
          <div className="flex pt-[4px] pl-2 w-[180px] h-[40px] nav3 absolute ml-8 mt-[1.5rem]">
            <Link to="/specialProducts">Discountable Products</Link>
          </div>
        </div>
        <div className="ml-[620px]">
          <div className="flex mr-2 pt-[4px] pl-2 w-[100px] h-[40px] nav3 absolute ml-8 mt-[1.5rem]">
            <Link to="/giftcards">Gift Cards</Link>
          </div>
        </div>
        <div className="ml-[775px]">
          <div className="flex pr-[20px] pt-[4px] pl-5 w-[140px] h-[40px] nav3 absolute mt-[1.5rem]">
            <Link to="/nkservices">.NK Services</Link>
          </div>
        </div>
        <div className="ml-[900px]">
          <div className="flex mr-2 pt-[4px] pl-2 w-[140px] h-[40px] nav3 absolute ml-8 mt-[1.5rem]">
            <Link to="/becomeaseller">Become a Seller</Link>
          </div>
        </div>
        <div className="ml-[1090px]">
          <div className="flex mr-2 pt-[4px] pl-4 w-[70px] h-[40px] nav3 absolute mt-[1.5rem]">
            <Link to="/ppc">PPC</Link>
          </div>
        </div>
        <div className="ml-[1150px]">
          <div className="flex mr-2 pt-[4px] pl-2 w-[140px] h-[40px] nav3 absolute ml-8 mt-[1.5rem]">
            <Link to="/specialProducts">Special Products</Link>
          </div>
        </div>
      </nav>
      <div
        className="white-line"
        style={{ height: "2px", width: "1200px", size: "100px" }}
      >
        .
      </div>
    </>
  );
};

export default Navigation;
