// Arrays In Java

// Arrays in Java are like a list of elements of the same type i.e. a list of integers, a list of booleans etc. 
// Creating an OneDArray (method 1) - with new keyword
// import java.util.*;

// public class OneDArray {
//    public static void main(String args[]) {
//     int[] marks = new int[3];
//     marks[0] = 97;
//     marks[1] = 98;
//     marks[2] = 95;

    // System.out.println(marks[0]);
    // System.out.println(marks[1]);
    // System.out.println(marks[2]);

//     // In another way
//     for(int i = 0; i < marks.length; i++){
//            System.out.println(marks[i]);
//                 }
//             }
//     }


// Creating an OneDArray (method 2)
// int[] marks = {98, 97, 95};

// Taking an array as an input and printing its elements.
// import java.util.*;
// public class OneDArray {
//    public static void main(String args[]) {
//        Scanner sc = new Scanner(System.in);
//        int size = sc.nextInt();
//        int numbers[] = new int[size];
//        for(int i=0; i<size; i++) {
//            numbers[i] = sc.nextInt();
//        }
//     //    print the numbers in array
//        for(int i=0; i<numbers.length; i++) {
//            System.out.print(numbers[i]+" ");
//        }
//    }
// }


// Take an array of names as input from the user and print them on the screen.
// import java.util.*;
// public class OneDArray {
//    public static void main(String args[]) {
//       Scanner sc = new Scanner(System.in);
//       int size = sc.nextInt();
//       String names[] = new String[size];
//     //   input
//       for(int i=0; i<size; i++) {
//           names[i] = sc.next();
//       }
//     //   output
//        for(int i=0; i<names.length; i++) {
//            System.out.println("name " + (i+1) +" is : " + names[i]);
//        }
//    }
// }

// Find the maximum & minimum number in an array of integers. 
// [HINT : Read about Integer.MIN_VALUE & Integer.MAX_VALUE in Java]
// import java.util.*;
// public class OneDArray {
//    public static void main(String args[]) {
//       Scanner sc = new Scanner(System.in);
//       int size = sc.nextInt();
//       int numbers[] = new int[size];
//     //   input
//       for(int i=0; i<size; i++) {
//           numbers[i] = sc.nextInt();
//       }
//       int max = Integer.MIN_VALUE;
//       int min = Integer.MAX_VALUE;
//        for(int i=0; i<numbers.length; i++) {
//            if(numbers[i] < min) {
//                min = numbers[i];
//            }
//            if(numbers[i] > max) {
//                max = numbers[i];
//            }
//        }
//        System.out.println("Largest number is : " + max);
//        System.out.println("Smallest number is : " + min);
//    }
// }

// Take an array of numbers as input and check if it is an array sorted in ascending order.
// Eg : { 1, 2, 4, 7 } is sorted in ascending order.
//        {3, 4, 6, 2} is not sorted in ascending order.

// import java.util.*;

// public class OneDArray{
//     public static void main(String[] args){
//     Scanner sc = new Scanner(System.in);
//     int size = sc.nextInt();
//     int numbers[] = new int [size];
//     for(int i=1; i<size; i++){
//     numbers[i] = sc.nextInt();
//     }

//     boolean isAscending = true;
//     for(int i = 1; i<numbers.length - 1; i++){
//         if(numbers[i]> numbers[i +1]){
//         isAscending = false;
//         }
//         if(numbers[i] < numbers[i + 1]){
//         System.out.println("Order is sorted in Ascending");
//         }else{
//             System.out.println("Order is sorted in Descending");
//         }
//     }
//     }
//     }