import { useState } from "react";
//  import { useNavigate } from "react-router-dom";
//  import {
//    useCreateProductMutation,
//    useUploadProductImageMutation,
//  } from "../../redux/api/productApiSlice";
//  import { useFetchCategoriesQuery } from "../../redux/api/categoryApiSlice";
//  import { toast } from "react-toastify";
//  import AdminMenu from "./AdminMenu";
const becomeaseller = () => {
  // const [cnic, setCnic] = useState("");
  // const [postalCode, setPostalCode] = useState("");
  // const [address, setaddress] = useState("");
  // const [debiteCard, setDebiteCard] = useState("");
  // const [expireDate, setExpireDate] = useState("");
  // const [code, setCode] = useState("");
  // const [addressCard, setAddressCard] = useState("");
  // const [imageUrl, setImageUrl] = useState(null);
  // const navigate = useNavigate();

  // const [uploadSellerImage] = useUploadProductImageMutation();
  // const [createProduct] = useCreateProductMutation();

  // const handleSubmit = async (e) => {
  //   e.preventDefault();

  //   try {
  //     const productData = new FormData();
  //     productData.append("image", image);
  //     productData.append("cnic", cnic);
  //     productData.append("postalCode", postalCode);
  //     productData.append("address", address);
  //     productData.append("debiteCard", debiteCard);
  //     productData.append("expireDate", expireDate);
  //     productData.append("code", code);
  //     productData.append("addressCard", addressCard);

  //     const { data } = await createProduct(productData);

  //     if (data.error) {
  //       toast.error("Product create failed. Try Again.");
  //     } else {
  //       toast.success(`${data.name} is created`);
  //       navigate("/");
  //     }
  //   } catch (error) {
  //     console.error(error);
  //     toast.error("Seller create failed. Try Again.");
  //   }
  // };

  // const uploadFileHandler = async (e) => {
  //   const formData = new FormData();
  //   formData.append("image", e.target.files[0]);

  //   try {
  //     const res = await uploadProductImage(formData).unwrap();
  //     toast.success(res.message);
  //     setImage(res.image);
  //     setImageUrl(res.image);
  //   } catch (error) {
  //     toast.error(error?.data?.message || error.error);
  //   }
  // };

  return (
    <div className="container xl:mx-[9rem] sm:mx-[0]">
      {/* <div className="flex flex-col md:flex-row">
         <AdminMenu />
         <div className="md:w-3/4 p-3">
           <div className="h-12">Create Product</div>

         {imageUrl && ( 
             <div className="text-center">
               <img
                 src={imageUrl}
                 alt="product"
                 className="block mx-auto max-h-[200px]"
               />
             </div>
           )}

           <div className="mb-3">
             <label className="border text-white px-4 block w-full text-center rounded-lg cursor-pointer font-bold py-11">
               {image ? image.name : "Upload Image"}

               <input
                 type="file"
                 name="image"
                 accept="image/*"
                 onChange={uploadFileHandler}
                 className={!image ? "hidden" : "text-white"}
               />
             </label>
           </div>

           <div className="p-3">
             <div className="flex pl-7">
               <div className="">
                 <label htmlFor="" className="my-5">
                   cnic
                 </label>
                 <br />
                 <input
                   type="text"
                   className="input-container-two bg-[#101011] border rounded-lg  text-white"
                   value={name}
                   onChange={(e) => setName(e.target.value)}
                 />
               </div>
               <div className="pl-6">
                 <label htmlFor="" className="my-5">
                   CNIC Number
                 </label>
                 <br />
                 <input
                   type="number"
                   className="input-container-two bg-[#101011] border rounded-lg  text-white"
                   value={price}
                   onChange={(e) => setPrice(e.target.value)}
                 />
               </div>
             </div>
             <br />{" "}
             <div className="flex pl-7">
               <div className="">
                 <label htmlFor="" className="my-5">
                   Postal Code
                 </label>
                 <br />
                 <input
                   type="number"
                   className="input-container-two bg-[#101011] border rounded-lg  text-white"
                   value={quantity}
                   onChange={(e) => setQuantity(e.target.value)}
                 />
               </div>
               <div className="pl-6">
                 <label htmlFor="" className="">
                   Address
                 </label>
                 <br />
                 <input
                   type="text"
                   className="input-container-two bg-[#101011] border rounded-lg  text-white"
                   value={brand}
                   onChange={(e) => setBrand(e.target.value)}
                 />
               </div>
             </div>
             <br />
             <label htmlFor="" className="my-5">
               Debite or Credit Card
             </label>
             <textarea
               type="text"
               className="p-2 mb-3 bg-[#101011] border rounded-lg w-[95%] text-white"
               value={description}
               onChange={(e) => setDescription(e.target.value)}
             />
             <br></br>
             <label htmlFor="" className="my-5">
               Expire Date
             </label>
             <textarea
               type="text"
               className="p-2 mb-3 bg-[#101011] border rounded-lg w-[95%] text-white"
               value={pdName2}
               onChange={(e) => setPdName2(e.target.value)}
             ></textarea>
             <br></br>
             <label htmlFor="" className="my-5">
               Code
             </label>
             <textarea
               type="text"
               className="p-2 mb-3 bg-[#101011] border rounded-lg w-[95%] text-white"
               value={description2}
               onChange={(e) => setDescription2(e.target.value)}
             ></textarea>
             <br></br>
             <label htmlFor="" className="my-5">
               Address Card
             </label>
             <button
               onClick={handleSubmit}
               className="py-4 px-10 mt-5 rounded-lg text-lg font-bold bg-pink-600"
             >
               Submit
             </button>
           </div>
         </div>
       </div> */}
    </div>
  );
};

export default becomeaseller;
