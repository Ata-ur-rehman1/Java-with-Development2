import React from "react";

const BrandsProductTen = () => {
  return <div>BrandsProductTen BrandsProductTen</div>;
};

export default BrandsProductTen;
