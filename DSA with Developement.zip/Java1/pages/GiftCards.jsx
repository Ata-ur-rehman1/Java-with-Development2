import React from "react";

const GiftCards = () => {
  return <div>GiftCards</div>;
};

export default GiftCards;
