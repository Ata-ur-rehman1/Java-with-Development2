import React from "react";

const BrandsProductTwo = () => {
  return <div>BrandsProductTwo BrandsProductTwo</div>;
};

export default BrandsProductTwo;
