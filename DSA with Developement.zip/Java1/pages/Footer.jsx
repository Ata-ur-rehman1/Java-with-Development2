import { Link } from "react-router-dom";
import React from "react";

const Footer = () => {
  return (
    <div>
      <footer style={{ paddingTop: "200px" }}>
        <div className="h-1" style={{ backgroundColor: "white" }}></div>
        <br></br>
        <br></br>
        <br></br>
        <br></br>
        <br></br>
        <div>
          <div
            style={{
              paddingLeft: "800px",
              paddingBottom: "200px",
            }}
          >
            <Link to="/policy">Privacy Policy</Link>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Footer;
