import React from "react";

const BrandsProductSix = () => {
  return <div>BrandsProductSix BrandsProductSix</div>;
};

export default BrandsProductSix;
