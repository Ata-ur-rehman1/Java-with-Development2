import { useEffect, useState } from "react";
import { toast } from "react-toastify";

import { useNavigate } from "react-router";
import { useDispatch, useSelector } from "react-redux";
import { useLocation } from "react-router";
import { useRegisterMutation } from "../../redux/api/usersApiSlice";
import { setCredentials } from "../../redux/features/auth/authSlice";
import Loader from "../../components/Loader";
import { Link } from "react-router-dom";
// import
const Register = () => {
  const [username, setUserName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const [register, { isLoading }] = useRegisterMutation();
  const { userInfo } = useSelector((state) => state.auth);
  const { search } = useLocation();
  const sp = new URLSearchParams(search);
  const redirect = sp.get("redirect") || "/";

  const navigate = new useNavigate();

  const dispatch = new useDispatch();

  useEffect(() => {
    if (userInfo) {
      navigate(redirect);
    }
  }, [navigate, redirect, userInfo]);

  const submitHandler = async (e) => {
    e.preventDefault();
    if (password !== confirmPassword) {
      toast.error("Passwords don't match.");
    } else {
      try {
        const res = await register({ username, email, password }).unwrap();
        dispatch(setCredentials({ ...res }));
        navigate(redirect);
        toast.success("Successfullly User Registered.");
      } catch (error) {
        toast.error(err.data.message);
      }
    }
  };
  return (
    <>
      <section>
        <form onSubmit={submitHandler}>
          <h1>User Registeration</h1>
          <h1>User Name</h1>
          <input
            type="text"
            value={username}
            onChange={(e) => setUserName(e.target.value)}
            placeholder="Enter User Name"
          />
          <h1>E-mail</h1>
          <input
            type="text"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Enter E-mail"
          />
          <h1>Password</h1>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Password"
          />
          <h1>Confirm Password</h1>
          <input
            type="password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            placeholder="Confirm Password"
          />
          <button disabled={isLoading} type="submit">
            {isLoading ? "Registering" : "Registered"}
          </button>
          {isLoading && <Loader />}
          <div>
            <p>Already have an account</p>
            <Link
              to={redirect ? `/login?redirect=${redirect}` : "/login"}
              className="text-pink-500 hover:underline"
            >
              Click here to login
            </Link>
          </div>
        </form>
      </section>
    </>
  );
};

export default Register;
