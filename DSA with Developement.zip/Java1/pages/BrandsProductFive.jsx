import React from "react";

const BrandsProductFive = () => {
  return <div>BrandsProductFive BrandsProductFive</div>;
};

export default BrandsProductFive;
