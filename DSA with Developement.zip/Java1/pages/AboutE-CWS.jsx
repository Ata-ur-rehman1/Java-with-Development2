import React from "react";
import { Link } from "react-router-dom";
const AboutEC = () => {
  return <div>About E-Commerce Website</div>;
};

export default AboutEC;
