import React from "react";

const BrandsProductNine = () => {
  return <div>BrandsProductNine BrandsProductNine</div>;
};

export default BrandsProductNine;
