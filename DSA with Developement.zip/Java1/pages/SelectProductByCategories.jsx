import { Link } from "react-router-dom";
import React from "react";

const SelectProductByCategories = () => {
  return (
    <div>
      <Link to="/CategoryShop">SelectProductByCategories</Link>
    </div>
  );
};

export default SelectProductByCategories;
