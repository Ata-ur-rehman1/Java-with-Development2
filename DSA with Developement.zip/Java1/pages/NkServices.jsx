import React from "react";

const NkServices = () => {
  return <div>.Nk Services</div>;
};

export default NkServices;
