import React from "react";

const BrandsProductFour = () => {
  return <div>BrandsProductFour BrandsProductFour</div>;
};

export default BrandsProductFour;
