import React from "react";
import { useState } from "react";
import "./ai.css";
const Ai = () => {
  const [value, setValue] = useState("");
  const [error, setError] = useState("");
  const [chatHistory, setChatHistory] = useState([]);
  const getResponse = async () => {
    if (!value) {
      setError("Error! You need to enter something");
      return;
    }
    //From here we're getting all pf the value which we provide in the search.
    try {
      const options = {
        method: "POST",
        body: JSON.stringify({
          history: chatHistory,
          message: value,
        }),
        headers: {
          "Content-Type": "application/json",
        },
      };
      // gemin is endpoints.
      const response = await fetch("http://localhost:5000/gemini", options);
      const data = await response.text();
      console.log(data);
      setChatHistory((oldChatHistort) => [
        ...oldChatHistort,
        {
          role: "user",
          parts: value,
        },
        {
          role: "model",
          parts: data,
        },
      ]);
      setValue("");
    } catch (error) {
      console.error(error);
      setError("Something went wrong! Please try again later.");
    }
  };
  const surpriseOptions = [
    "Tell me! about Pakistan's fashion in summer.",
    "Tell me! about Pakistan's fashion in winter.",
    "What is the specification of iPhone 12?",
    "Give me! updates of iPhone 12.",
    "What is the specification of iPhone 12 mini?",
    "Give me! updates of iPhone 12 mini.",
    "What is the specification of iPhone 12 pro?",
    "Give me! updates of iPhone 12 pro.",
    "What is the specification of iPhone 12 pro max?",
    "Give me! updates of iPhone 12 pro max.",
    "Which iPhone is coming in coming days?",
    "What is the specification of iPhone 13?",
    "Give me! updates of iPhone 13.",
    "What is the specification of iPhone 13 mini?",
    "Give me! updates of iPhone 13 mini.",
    "What is the specification of iPhone 13 pro?",
    "Give me! updates of iPhone 13 pro.",
    "What is the specification of iPhone 13 pro max?",
    "Give me! updates of iPhone 13 pro max.",
    "What is the specification of iPhone 14?",
    "Give me! updates of iPhone 14.",
    "What is the specification of iPhone 14 mini?",
    "Give me! updates of iPhone 14 mini.",
    "What is the specification of iPhone 14 pro?",
    "Give me! updates of iPhone 14 pro.",
    "What is the specification of iPhone 14 pro max?",
    "Give me! updates of iPhone 14 pro max.",
    "What is the specification of iPhone 15?",
    "Give me! updates of iPhone 15.",
    "What is the specification of iPhone 15 mini?",
    "Give me! updates of iPhone 15 mini.",
    "What is the specification of iPhone 15 pro?",
    "Give me! updates of iPhone 15 pro.",
    "What is the specification of iPhone 15 pro max?",
    "Give me! updates of iPhone 15 pro max.",
  ];
  const surprise = () => {
    const randomValue =
      surpriseOptions[Math.floor(Math.random() * surpriseOptions.length)];
    setValue(randomValue);
  };

  const clear = () => {
    setValue("");
    setError("");
    setChatHistory([]);
  };
  return (
    <div className="app">
      <p>
        What do you want to search?
        <button className="surprise" onClick={surprise} disabled={!chatHistory}>
          Surprise me!
        </button>
      </p>
      <div className="input-container1">
        <input
          className="input"
          type="text"
          value={value}
          placeholder="Type here to search"
          onChange={(e) => setValue(e.target.value)}
        />
        {!error && <button onClick={getResponse}>Ask me</button>}
        {error && <button onClick={clear}>Clear</button>}
      </div>
      {error && <p>{error}</p>}
      <div className="search-result">
        {chatHistory.map((chatItem, _index) => (
          <div key={_index}>
            <p className="anwser">
              {chatItem.role} : {chatItem.parts}
            </p>
          </div>
        ))}
      </div>{" "}
    </div>
  );
};
export default Ai;
