import React from "react";

const Ppc = () => {
  return <div>PPC</div>;
};

export default Ppc;
