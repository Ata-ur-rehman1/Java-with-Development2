import React from "react";

const BrandsProductSeven = () => {
  return <div>BrandsProductSeven BrandsProductSeven</div>;
};

export default BrandsProductSeven;
