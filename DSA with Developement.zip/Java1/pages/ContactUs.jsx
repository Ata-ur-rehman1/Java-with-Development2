import React from "react";
import { Link } from "react-router-dom";
const ContactUs = () => {
  return (
    <>
      {" "}
      <div>ContactUs</div>
      <Link
        style={{
          height: "200px",
          justifyContent: "center",
          paddingTop: "200px",
          paddingLeft: "850px",
        }}
        to="/about"
      >
        About E-commerce Website
      </Link>
    </>
  );
};

export default ContactUs;
