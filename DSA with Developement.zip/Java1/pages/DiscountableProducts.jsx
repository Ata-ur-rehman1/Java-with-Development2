import React from "react";

const DiscountableProducts = () => {
  return <div>Discountable Products</div>;
};

export default DiscountableProducts;
