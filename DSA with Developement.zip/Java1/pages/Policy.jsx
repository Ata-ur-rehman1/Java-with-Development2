import React from "react";
import { Link } from "react-router-dom";
const Policy = () => {
  return (
    <>
      {" "}
      <div>policy</div>
      <Link
        style={{
          height: "200px",
          justifyContent: "center",
          paddingTop: "200px",
          paddingLeft: "850px",
        }}
        to="/contact"
      >
        Contact Us
      </Link>
    </>
  );
};

export default Policy;
