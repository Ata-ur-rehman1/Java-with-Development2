import React from "react";

const BrandsProductEight = () => {
  return <div>BrandsProductEight BrandsProductEight</div>;
};

export default BrandsProductEight;
