import React from "react";

const SellerForm = () => {
  return (
    <>
      <div className="mb-4">
        <label
          htmlFor="password"
          className="block text-sm font-medium text-white ml-[80px]"
        >
          Front CNIC or Passport Photo
        </label>
        <input
          type="number"
          id="password"
          className="mt-1 p-2 border rounded ml-[80px] w-[800px]"
          placeholder="Enter Yes or Not"
          // value={password}
          // onChange={(e) => setPassword(e.target.value)}
        />
      </div>

      <div className="mb-4">
        <label
          htmlFor="password"
          className="block text-sm font-medium text-white ml-[80px]"
        >
          Back CNIC or Passport Photo
        </label>
        <input
          type="number"
          id="password"
          className="mt-1 p-2 border rounded ml-[80px] w-[800px]"
          placeholder="Enter Yes or Not"
          // value={password}
          // onChange={(e) => setPassword(e.target.value)}
        />
      </div>
      <div className="mb-4">
        <label
          htmlFor="password"
          className="block text-sm font-medium text-white ml-[80px]"
        >
          Reign
        </label>
        <input
          type="text"
          id="password"
          className="mt-1 p-2 border rounded ml-[80px] w-[800px]"
          placeholder="Enter Yes or Not"
          // value={password}
          // onChange={(e) => setPassword(e.target.value)}
        />
      </div>

      <div className="mb-4">
        <label
          htmlFor="password"
          className="block text-sm font-medium text-white ml-[80px]"
        >
          Address Available on Card
        </label>
        <input
          type="text"
          id="password"
          className="mt-1 p-2 border rounded ml-[80px] w-[800px]"
          placeholder="Enter Yes or Not"
          // value={password}
          // onChange={(e) => setPassword(e.target.value)}
        />
      </div>
      <button
        // disabled={isLoading}
        type="submit"
        className="ml-[100px] bg-pink-500 text-white px-4 py-2 rounded cursor-pointer my-[1rem]"
      >
        Next
      </button>
    </>
  );
};

export default SellerForm;
