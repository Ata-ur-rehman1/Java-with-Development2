public class StringBuilder2 {
    public static void main(String args[]) {
        StringBuilder sb = new StringBuilder("Numan");
        //Insert char
        sb.insert(0, 'S');
        System.out.println(sb);
      }
}
