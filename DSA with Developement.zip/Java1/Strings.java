// String
    // 1. CharAt.
    // 2. Substring.
// String name = "Numan";
// // Taking Input
// Scanner sc = new Scanner(System.in);
//        String name = sc.next();
// // Concatenation (Joining 2 d)
// String firstName = "Numan";
//        String secondName = "Khan";
//        String fullName = firstName + " " + secondName;
//        System.out.println(fullName);

// // Print length of a String
// String firstName = "Numan";
//        String secondName = "Khana";
//        String fullName = firstName + " " + secondName;
//        System.out.println(fullName.length());
// // Access characters of a string
// String firstName = "Numankhan";
//        String secondName = "Badshah";
//        String fullName = firstName + " " + secondName;
//        for(int i=0; i<fullName.length(); i++) {
//            System.out.println(fullName.charAt(i));
//        }
// Compare 2 d
// import java.util.*;
// public class Strings {
//    public static void main(String[] agrs){
//     String firstName = "Numankhan";
//     String secondName = "Badshah";
//     String fullName = firstName + " " + secondName;
//     // for(int i=0; i<fullName.length(); i++) {
//     //     System.out.println(fullName.charAt(i));
//     // }
//     System.out.println(fullName);
//     }
// }
// import java.util.*;
// public class Strings {
//    public static void main(String args[]) {
//        String name1 = "Numan";
//        String name2 = "Numa";
    // To compare the two strings we use firstSrting.equals(secondString).
//        if(name1.equals(name2)) {
//            System.out.println("They are the same string");
//        } else {
//            System.out.println("They are different string");
//        }
//        DO NOT USE == to check for string equality
//        Gives correct answer here
//        if(name1 == name2) {
//            System.out.println("They are the same string");
//        } else {
//            System.out.println("They are different d");
//        }

//        //Gives incorrect answer here
//        if(new String("Numan") == new String("Numan")) {
//            System.out.println("They are the same string");
//        } else {
//            System.out.println("They are different d");
//         }
//    }
// }

// Substring
// The substring of a string is a subpart of it.
// public class Strings {
//    public static void main(String args[]) {
//        String name = "TonyKhana";
//        System.out.println(name.substring(0, 4));
//    }
// }

// ALWAYS REMEMBER : Java Strings are Immutable(Never Change).
// Take an array of Strings input from the user & find the cumulative (combined) length of all those Strings.
// import java.util.*;
// public class Strings {
//    public static void main(String args[]) {
//      Scanner sc = new Scanner (System.in);
//      int size = sc.nextInt();
//      String array[] = new String[size];
//      int totLength = 0;
//      for(int i=0; i<size; i++) {
//        array[i] = sc.next();
//        totLength += array[i].length();
//      }
//      System.out.println(totLength);
//    }
// }

// Input a string from the user. Create a new string called ‘result’ in which you will replace the letter ‘e’ in the original string with letter ‘i’. 
// Example : 
// original = “eabcdef’ ; result = “iabcdif”
// Original = “xyz” ; result = “xyz”

// import java.util.*;


// public class Strings {
//    public static void main(String args[]) {
//      Scanner sc = new Scanner(System.in);
//      String str = sc.next();
//      String result = "";
//      for(int i=0; i<str.length(); i++) {
//        if(str.charAt(i) == 'e') {
//          result += 'i';
//        } else {
//          result += str.charAt(i);
//        }
//      }
//      System.out.println(result);
//    }
// }

// import java.util.*;
// public class Strings {
//    public static void main(String args[]) {
//      Scanner sc = new Scanner (System.in);
//      String email = sc.next();
//      String userName = "";
//     for(int i=0; i<email.length(); i++) {
//        if(email.charAt(i) == '@') {
//         break;
//        } else {
//          userName += email.charAt(i);
//        }
//      }
//      System.out.println(userName);
//    }
// }
