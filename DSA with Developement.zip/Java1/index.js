const str = " MY NAME IS Numan Khan";
const newStr = str.charCodeAt(2);
console.log(newStr);
