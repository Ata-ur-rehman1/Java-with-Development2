// String Builder
// 1. Append
//2. Insert 
//3. CharAt
// 4. SetcharAt
// Declaration
// StringBuilder sb = new StringBuilder("Numan Khan");
//      System.out.println(sb);

// Get A Character from Index
// StringBuilder sb = new StringBuilder("Numan");
//      //Set Char
//      System.out.println(sb.charAt(0));



// Set a Character at Index
// StringBuilder sb = new StringBuilder("Numan");
//      //Get Char
//      sb.setCharAt(0, 'P');
//      System.out.println();



// Insert a Character at Some Index

// import java.util.*;

// public class Stringbuilder {
//    public static void main(String args[]) {
//      StringBuilder sb = new StringBuilder("Numan");
//      //Insert char
//      sb.insert(0, 'S');
//      System.out.println(sb);
//    }
// }

// Delete char at some Index
// import java.util.*;
// public class Stringbuilder {
//    public static void main(String args[]) {
//      StringBuilder sb = new StringBuilder("Numan");
//      //Insert char
//      sb.insert(0, 'S');
//      System.out.println(sb);
	//delete char
    //  sb.delete(0, 1);
    //  System.out.println(sb);
//    }
// }
// Append a char 
// Append means to add something at the end.
// import java.util.*;
// public class Stringbuilder {
//    public static void main(String args[]) {
//      StringBuilder sb = new StringBuilder("Numan");
        // Append is used to write char after the StringBuilder 
//      sb.append(" Khan");
//      System.out.println(sb); 
//    }
// }

// Print Length of String
// import java.util.*;
// public class Stringbuilder {
//    public static void main(String args[]) {
//      StringBuilder sb = new StringBuilder("Numan");
//      sb.append(" Khan");
//      System.out.println(sb); 
//      System.out.println(sb.length());
//    }
// }

// Reverse a String (using StringBuilder class)


// import java.util.*;
// public class Stringbuilder{
//    public static void main(String args[]) {
//      StringBuilder sb = new StringBuilder("NumanKhan");
//      for(int i=0; i<sb.length()/2; i++) {
//        int front = i;
//        int back = sb.length() - i - 1;
//        char frontChar = sb.charAt(front);
//        char backChar = sb.charAt(back);
//        sb.setCharAt(front, backChar);
//        sb.setCharAt(back, frontChar);
//      }
//      System.out.println(sb);
//    }
// }
