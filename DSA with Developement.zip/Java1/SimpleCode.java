import java.util.*;
public class SimpleCode{
public static void main(String args[]){
    Scanner sc = new Scanner(System.in);
    int quizz = sc.nextInt();
    int assignment = sc.nextInt();
    int midterm = sc.nextInt();
    int finalterm = sc.nextInt();
    int sum = quizz + assignment + midterm + finalterm;
    System.out.println("Enter marks");
    int obtainMarks = sc.nextInt();
    int percentage = obtainMarks*100/sum;
    if(percentage >= 50 && percentage < 100){
        System.out.print("Obtain marks: " + obtainMarks + " and Pass");
    }else{
        System.out.print("Obtain marks: " + obtainMarks + " and Fail");
    }
}
}
